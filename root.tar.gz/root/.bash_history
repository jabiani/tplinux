history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
cat /etc/resolv.conf v
powerofff
poweroff
sudo cat /etc/hash 
cd /usr/local/bin/
ls -ltr
ls -l
base64 -d -i < cat /etc/hash 
cat /etc/hash 
cat /etc/hash  > base64 -d -i
cat /etc/hash | base64 -d -i
rm /etc/hash 
chatrr -i /etc/hash 
cd /etc/
ls -l |has
ls -l |hash
ls -ltr 
chatrr +i hash 
chattr -i /etc/hash 
rm /etc/hash 
ls -l
reboot
history
shutdown now
nano /etc/hosts
exec /sbin/init
apt install -y openssh-server
cat > /etc/apt/sources.list << 'EOF'
deb http://deb.debian.org/debian bookworm main contrib non-free-firmware
deb http://deb.debian.org/debian bookworm-updates main contrib non-free non-free-firmware
deb http://security.debian.org/debian-security bookworm-security main contrib non-free non-free-firmware
EOF

apt update
apt upgrade --without-new-pkgs -y
apt full-upgrade -y
apt autoremove -y
reboot
cat /etc/os-release
ls -la /root
ls -la /root/.ssh 2>/dev/null
apt install -y openssh-server
systemctl enable --now ssh
sssssss
s
palermo
systemctl status ssh
shutdown
echo "PermitRootLogin prohibit-password" > /etc/ssh/sshd_config.d/root.conf
systemctl restart ssh
ip route | grep default
nano /etc/network/interfaces
apt install -y nano
nano /etc/network/interfaces
echo "nameserver 8.8.8.8" > /etc/resolv.conf
systemctl restart networking
ip -4 a show enp0s3
ip route
ping -c 2 cefalia.app
poweroff
ss
cat /etc/fstab
cp /etc/fstab /etc/fstab.bak
awk '!see[$0]++' /etc/fstab > /tmp/fstab.new && cp /tmp/fstab.new /etc/fstab
ca /etc/fstab
cat /etc/fstab
mount -a && echo OK
reboot
echo "hola"
lsblk
fdisk /dev/sdc << 'EOF'
n
p
1

+3G
n
p
2

+6G
t
1
83
t
2
83
p
w
EOF

mkfs.ext4 -L www_dir /dev/sdc1
mkfs.ext4 -L backup_dir /dev/sdc2
mkdir -p /www_dir /backup_dir
echo "UUID=$(blkid -s UUID -o value /dev/sdc1)  /www_dir     ext4  defaults  0  2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2)  /backup_dir  ext4  defaults  0  2" >> /etc/fstab
systemctl daemon-reload
mount -a
df -h | grep _dir
mkfs.ext4 -L www_dir /dev/sdc1
mkfs.ext4 -L backup_dir /dev/sdc2
mkdir -p /www_dir /backup_dir
echo "UUID=$(blkid -s UUID -o value /dev/sdc1)  /www_dir     ext4  defaults  0  2" >> /etc/fstab
echo "UUID=$(blkid -s UUID -o value /dev/sdc2)  /backup_dir  ext4  defaults  0  2" >> /etc/fstab
systemctl daemon-reload
mount -a
df -h | grep _dir
df -h
cat /etc/fstab
cp /var/www/html/index.php /var/www/html/logo.png /www_dir/
chown -R www-data:www-data /www_dir
sed -i 's#/var/www/html#/www_dir#g' /etc/apache2/sites-available/000-default.conf
sed -i 's#<Directory /var/www/>#<Directory /www_dir/>#' /etc/apache2/apache2.conf
apache2ctl configtest
systemctl restart apache2
grep -n www_dir /etc/apache2/sites-available/000-default.conf /etc/apache2/apache2.conf
cat /proc/partitions > /opt/particion
cat /opt/particion
