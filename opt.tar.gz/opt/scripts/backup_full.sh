#!/bin/bash
# backup_full.sh - Backup comprimido de un directorio con fecha ANSI (YYYYMMDD)
# Uso: backup_full.sh <origen> <destino>

mostrar_ayuda() {
    cat << AYUDA
Uso: $0 <origen> <destino>
     $0 -help

Realiza un backup comprimido (.tar.gz) del directorio ORIGEN y lo
guarda en DESTINO con el formato: <nombre>_bkp_YYYYMMDD.tar.gz

Argumentos:
  origen    Directorio a respaldar (ej: /var/log)
  destino   Directorio donde guardar el backup (ej: /backup_dir)

Opciones:
  -help     Muestra esta ayuda

Ejemplo:
  $0 /var/log /backup_dir
  -> genera /backup_dir/log_bkp_$(date +%Y%m%d).tar.gz
AYUDA
}

# --- Ayuda ---
if [ "$1" = "-help" ] || [ "$1" = "--help" ] || [ "$1" = "-h" ]; then
    mostrar_ayuda
    exit 0
fi

# --- Validar cantidad de argumentos ---
if [ $# -ne 2 ]; then
    echo "ERROR: se requieren 2 argumentos (origen y destino)." >&2
    echo "Use '$0 -help' para ver la ayuda." >&2
    exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# --- Validar que el origen exista y esté disponible ---
if [ ! -d "$ORIGEN" ]; then
    echo "ERROR: el origen '$ORIGEN' no existe o no es un directorio." >&2
    exit 2
fi
if ! df "$ORIGEN" > /dev/null 2>&1; then
    echo "ERROR: el sistema de archivos del origen '$ORIGEN' no está disponible." >&2
    exit 2
fi

# --- Validar que el destino exista, esté montado y sea escribible ---
if [ ! -d "$DESTINO" ]; then
    echo "ERROR: el destino '$DESTINO' no existe o no es un directorio." >&2
    exit 3
fi
if ! df "$DESTINO" > /dev/null 2>&1; then
    echo "ERROR: el sistema de archivos del destino '$DESTINO' no está disponible." >&2
    exit 3
fi
if ! mountpoint -q "$DESTINO"; then
    echo "ADVERTENCIA: '$DESTINO' no es un punto de montaje; se continúa igualmente." >&2
fi
if [ ! -w "$DESTINO" ]; then
    echo "ERROR: no hay permiso de escritura en '$DESTINO'." >&2
    exit 3
fi

# --- Armar nombre del archivo ---
NOMBRE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
ARCHIVO="$DESTINO/${NOMBRE}_bkp_${FECHA}.tar.gz"

# --- Ejecutar backup ---
echo "Iniciando backup de '$ORIGEN' en '$ARCHIVO'..."
if tar -czf "$ARCHIVO" -C "$(dirname "$ORIGEN")" "$NOMBRE" 2>/dev/null; then
    echo "Backup finalizado correctamente: $ARCHIVO ($(du -h "$ARCHIVO" | cut -f1))"
    exit 0
else
    echo "ERROR: falló la generación del backup." >&2
    exit 4
fi
